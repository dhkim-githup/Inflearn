package com.example.webstory.vo;


import lombok.Data;

@Data
public class People {
	
	private String strID;
	private String strName;
	private String strAge;
	private String strDati;
	

	

}