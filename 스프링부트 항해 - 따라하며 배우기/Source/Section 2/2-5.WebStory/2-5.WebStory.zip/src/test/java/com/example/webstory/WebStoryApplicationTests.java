package com.example.webstory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebStoryApplicationTests {

    @Test
    void contextLoads() {
    }

}
