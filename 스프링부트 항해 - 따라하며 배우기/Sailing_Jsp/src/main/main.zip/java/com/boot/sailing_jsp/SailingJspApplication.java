package com.boot.sailing_jsp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SailingJspApplication {

    public static void main(String[] args) {
        SpringApplication.run(SailingJspApplication.class, args);
    }

}
