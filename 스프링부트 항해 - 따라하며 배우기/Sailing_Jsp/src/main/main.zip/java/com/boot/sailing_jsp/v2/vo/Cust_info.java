package com.boot.sailing_jsp.v2.vo;

import lombok.Data;

@Data
public class Cust_info {

    private String no;
    private String cust_id;
    private String name;
    private String email;
    private String role;
    private String reg_day;

}
