package com.boot.sailing_jsp.v2.vo;

import lombok.Data;

@Data
public class Order_list {

    private String no;
    private String coffee_no;
    private String coffee;
    private String price;
    private String cust_id;
    private String name;
    private String reg_day;



}
